"""
CTE213: Automated Conveyor Belt Production and Fault Detection System
Student: Bai Daniel Kelvin | Matric: F/ND/24/3450011
ND II Mechatronics Engineering, Yaba College of Technology (YABATECH)

Educational simulation only. It does not control real industrial machinery.
"""
from datetime import datetime
import csv

MIN_LENGTH_CM = 9.5
MAX_LENGTH_CM = 10.5
MAX_MOTOR_TEMP_C = 75.0

production_records = []
fault_history = []
total_produced = 0
accepted_total = 0
rejected_total = 0


def get_number(prompt, minimum=0):
    while True:
        try:
            value = float(input(prompt))
            if value < minimum:
                print(f"Enter a value of at least {minimum}.")
                continue
            return value
        except ValueError:
            print("Please enter a valid number.")


def get_positive_integer(prompt):
    while True:
        try:
            value = int(input(prompt))
            if value > 0:
                return value
            print("Enter a whole number greater than zero.")
        except ValueError:
            print("Please enter a whole number.")


def log_fault(message):
    event = {"time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
             "fault": message}
    fault_history.append(event)
    print("FAULT RECORDED:", message)


def inspect_machine():
    print("\n--- PRE-START MACHINE INSPECTION ---")
    sensor = input("Is the object sensor working? (y/n): ").strip().lower()
    motor = input("Is the motor status normal? (y/n): ").strip().lower()
    emergency = input("Is the emergency stop activated? (y/n): ").strip().lower()

    faults = []
    if sensor != "y":
        faults.append("Object sensor failure")
    if motor != "y":
        faults.append("Abnormal motor status")
    if emergency == "y":
        faults.append("Emergency stop activated")

    if faults:
        for item in faults:
            log_fault(item)
        print("Inspection failed. The simulated production batch is blocked.")
        return False

    print("Inspection passed. Simulated conveyor is ready.")
    return True


def inspect_product(length):
    return "ACCEPTED" if MIN_LENGTH_CM <= length <= MAX_LENGTH_CM else "REJECTED"


def run_batch():
    global total_produced, accepted_total, rejected_total
    print("\n--- PRODUCTION BATCH ---")
    if not inspect_machine():
        return

    batch = input("Batch/product name: ").strip() or "Unnamed Batch"
    count = get_positive_integer("Number of products to simulate: ")
    batch_accepted = 0
    batch_rejected = 0

    for number in range(1, count + 1):
        print(f"Product {number} of {count}")
        length = get_number("Measured length in cm: ", minimum=0.1)
        result = inspect_product(length)
        total_produced += 1

        if result == "ACCEPTED":
            accepted_total += 1
            batch_accepted += 1
        else:
            rejected_total += 1
            batch_rejected += 1
            print("Quality-control decision: divert this product to the reject section.")

        production_records.append({
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "batch": batch,
            "product_number": total_produced,
            "length_cm": round(length, 2),
            "result": result
        })
        print("Inspection result:", result)

    print("\nBATCH SUMMARY")
    print("Batch:", batch)
    print("Processed:", count)
    print("Accepted:", batch_accepted)
    print("Rejected:", batch_rejected)
    print(f"Acceptance rate: {batch_accepted / count * 100:.1f}%")


def check_motor_temperature():
    print("\n--- MOTOR TEMPERATURE CHECK ---")
    temperature = get_number("Enter simulated motor temperature (°C): ")
    if temperature > MAX_MOTOR_TEMP_C:
        log_fault(f"Motor over-temperature: {temperature:.1f}°C")
        print("Suggested response: stop the simulated line and inspect cooling.")
    else:
        print(f"Temperature is within the {MAX_MOTOR_TEMP_C:.1f}°C limit.")


def check_belt_jam():
    print("\n--- BELT-JAM SENSOR SIMULATION ---")
    answer = input("Has an obstruction been detected? (y/n): ").strip().lower()
    if answer == "y":
        log_fault("Conveyor belt obstruction/jam detected")
        print("Simulated response: stop the line and clear the obstruction safely.")
    elif answer == "n":
        print("No belt obstruction reported.")
    else:
        print("Invalid response. Enter y or n.")


def production_report():
    print("\n========== PRODUCTION REPORT ==========")
    print("Total processed:", total_produced)
    print("Accepted:", accepted_total)
    print("Rejected:", rejected_total)
    if total_produced:
        print(f"Acceptance rate: {accepted_total / total_produced * 100:.1f}%")
        print(f"Rejection rate: {rejected_total / total_produced * 100:.1f}%")
    else:
        print("No production has been recorded.")
    print("Fault events:", len(fault_history))


def show_fault_history():
    print("\n========== FAULT HISTORY ==========")
    if not fault_history:
        print("No faults recorded.")
    for index, event in enumerate(fault_history, start=1):
        print(f"{index}. [{event['time']}] {event['fault']}")


def export_csv():
    try:
        with open("production_records.csv", "w", newline="", encoding="utf-8") as file:
            fields = ["timestamp", "batch", "product_number", "length_cm", "result"]
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            writer.writerows(production_records)

        with open("fault_history.csv", "w", newline="", encoding="utf-8") as file:
            fields = ["time", "fault"]
            writer = csv.DictWriter(file, fieldnames=fields)
            writer.writeheader()
            writer.writerows(fault_history)
        print("Exported production_records.csv and fault_history.csv.")
    except OSError as error:
        print("Export failed:", error)


def main():
    print("=" * 55)
    print("AUTOMATED CONVEYOR BELT PRODUCTION SYSTEM")
    print("Student: Bai Daniel Kelvin")
    print("Matric No.: F/ND/24/3450011")
    print("Educational simulation only - not for real machine control.")
    while True:
        print("\n1. Inspect machine sensors")
        print("2. Run production batch")
        print("3. Check motor temperature")
        print("4. Simulate belt-jam detection")
        print("5. View production report")
        print("6. View fault history")
        print("7. Export records to CSV")
        print("0. Exit")
        choice = input("Choose an option: ").strip()

        if choice == "1":
            inspect_machine()
        elif choice == "2":
            run_batch()
        elif choice == "3":
            check_motor_temperature()
        elif choice == "4":
            check_belt_jam()
        elif choice == "5":
            production_report()
        elif choice == "6":
            show_fault_history()
        elif choice == "7":
            export_csv()
        elif choice == "0":
            print("Thank you for using the system.")
            break
        else:
            print("Invalid choice. Select 0 to 7.")


if __name__ == "__main__":
    main()
